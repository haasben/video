<?php

namespace app\index\controller;

use think\Controller;
use think\Db;
use think\Session;

class Base extends Controller
{

    //语言
	public $lang;

    //类别
    public $cate = array();

    public $users_id;
	/*
     * 初始化操作
     */
    public function _initialize() 
    {	
        
       
        parent::_initialize();
         if(isMobile()){
            $this->redirect('/m');exit;
        }
        $lang = 'cn';

        $this->lang = $lang;
        //增加浏览量
        add_scan();
        //网站信息
        $web_config = web_config();
        
        $this->assign('web_config',$web_config);


        //登录信息
        $userData = session('users_info');
        if(!empty($userData)){
            $this->users_id = $userData['users_id'];
            $userData['view_rights'] = explode(',', $userData['view_rights']);
            // dump($userData);die;
        }
        $this->assign('userData',$userData);
        $arctypeModel = Db::name('arctype');
        $cate_footer = $arctypeModel
            ->field('id,typename,dirname,seo_title,seo_keywords,seo_description,typelink,litpic,is_part')
            ->where('lang',$this->lang)
            ->where('status',1)
            ->where('is_del',0)
            ->where('parent_id',0)
            ->where('is_hidden',0)
            ->order('sort_order')
            ->select();
        foreach ($cate_footer as $k => $v) {
            $cate_footer[$k]['child'] =$arctypeModel
            ->field('id,typename,dirname,seo_title,seo_keywords,seo_description,typelink,litpic,is_part')
            ->where('lang',$this->lang)
            ->where('status',1)
            ->where('is_del',0)
            ->where('parent_id',$v['id'])
            ->where('is_hidden',0)
            ->order('sort_order')
            ->select();
            if($k !=0){
                $this->cate = array_merge($this->cate,$cate_footer[$k]['child']);
            }
            
        }

        $this->assign('cate_footer',$cate_footer);


    }

    




}










?>